# 1.2 Kokoro 离线语音版本验证

日期：2026-10-24。工具：JDK 21.0.4、Gradle 8.9、AGP 8.7.3、Android SDK 35 / Build Tools 35.0.0。

`testDebugUnitTest lintDebug assembleDebug` 成功。11 项 JUnit 测试通过：CSV、播放顺序与过期回调、长文本分段及 JNI 回调精确签名。Lint 0 errors / 7 warnings。保留仅针对 MediaSession 媒体通知豁免的局部 lint 注释。

## 离线推理验证

使用 sherpa-onnx 1.12.15 Linux 官方运行库及相同 Kokoro 模型实际生成 `Curious. I am curious about the world.`：24 kHz 单声道 WAV、2.586 秒，PCM 非静音。示例文件位于 `/workspace/WordFlow-Kokoro-sample.wav`。

另外用 Android AAR 内的原始 Java API 类、同版本 Linux JNI 运行库、应用实际使用的 `KokoroCallback` 类进行测试，得到 33,336 个有限非零 PCM 样本、峰值约 0.3032，11 个声音；返回 0 能取消后续原生回调。此检查发现并修复了 Java lambda 缺少 JNI 所需 `invoke(float[]):Integer` 入口的问题。可复用的测试源文件见 `scripts/KokoroJniSmoke.java`。

## APK 验证

- 包名 `cn.wordflow.app`，版本 1.2（3），minSdk 26 / targetSdk 35，包含 ARM64 及 ARM32 原生库。
- APK v2 签名、16 KB zipalign 验证通过，ARM64 所有 ELF LOAD 段对齐至少 16 KB。
- 签名与交付的 1.1 一致，可以覆盖安装，词表数据格式未改变。
- APK 内 ONNX 模型 SHA-256 与固定源模型一致，包含 voices、tokens、eSpeak 英语词典及许可。
- APK 无 INTERNET 权限，无系统 TTS 引擎依赖，模型完整内置。
- APK 大小：149213883 字节。SHA-256：`1aed3ac336fff9e02c6b0c773ff7f7a8c311d44c1f8a291e7b02676995253721`。

模型下载包 SHA-256：`c9f0dd393615805b0bab050c340834d5e684e732aec91c0e860cd30e982c08bd`。
AAR SHA-256：`6994c53380846107b0363fee02fa9db6176c61c746a2315893c6b01e7f6d4c1d`。

尚未完成安卓模拟器或小米真机的音频输出、安装升级和长期息屏验收。Linux 推理测试不等同于手机端完整验收，合成速度因设备而异。
