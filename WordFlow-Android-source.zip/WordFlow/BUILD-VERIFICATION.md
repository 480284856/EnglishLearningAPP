# 1.3 语音缓存版本验证

日期：2026-10-24。JDK 21.0.4、Gradle 8.9、AGP 8.7.3、Android SDK / Build Tools 35。

`testDebugUnitTest lintDebug assembleDebug` 成功。20 项 JUnit 测试通过：CSV、播放顺序与旧回调、分段、JNI 入口签名，以及 9 项缓存测试，覆盖持久化后读取、文本 / 模型 / 声音 / 语速隔离、未完成写入和原子替换、CRC 损坏 / 截断、LRU 容量限制、预缓存满额保留、清理范围、异常退出临时文件、非法 PCM。Lint 0 errors / 7 warnings。

## 实际模型与缓存验证

使用 sherpa-onnx 1.12.15 的原始 Android API 类、同版 Linux JNI、实际应用中的 SpeechCache 与 KokoroCallback 生成 `Hello, learner.`，保存 33,375 个 PCM 帧并关闭；重新构造缓存后读取到完全相同帧数与峰值，没有第二次调用模型。更换语速未命中旧缓存，取消原生合成后的部分音频没有成为有效缓存。见 `scripts/KokoroCacheSmoke.java`，日志 `/workspace/kokoro-build/cache-smoke.log`。

## 行为

首次完整合成自动缓存；缓存命中直接通过 AudioTrack 输出，无 Kokoro 推理。文本、语速、声音和模型版本参与 SHA-256 键。完整文件带 CRC32 校验并原子提交，取消或异常只遗留临时文件，重启时清理。缓存上限 256 MB，普通播放按最近使用时间淘汰；预缓存满额停止且保留已完成内容。

批量预缓存使用 dataSync 前台服务及可取消的进度通知，听读仍使用 mediaPlayback 前台服务。批量任务不请求音频焦点。任务取消、结束、失败、系统超时及销毁释放唤醒锁；长任务按分段进度续期。清理音频不删除词表或 Kokoro 模型。

## APK

包名 cn.wordflow.app，版本 1.3（4），minSdk 26 / targetSdk 35，ARM64 / ARM32。签名与已交付 1.2 相同，支持覆盖安装。APK v2 签名及 16 KB zipalign 验证通过。内置 ONNX 模型哈希与 1.2 相同，不需重新下载模型。

APK：149260554 字节，SHA-256 `8644e4d7611d65fe0d7805d38698a4d229cba53f7182f7a8717888c0406a2fd6`。

尚未在安卓模拟器或小米真机验收 AudioTrack 输出、通知授权、后台预缓存、Android 15 dataSync 超时和长时间息屏。Linux 模型 / 缓存测试不等于设备端完整验收。
