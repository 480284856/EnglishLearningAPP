package cn.wordflow.app;

import android.content.Context;
import android.util.AtomicFile;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

final class WordStore {
    static final class Deck {
        final String name;
        final List<CsvParser.Entry> entries;
        Deck(String name, List<CsvParser.Entry> entries) { this.name = name; this.entries = entries; }
        @Override public String toString() { return name + "  ·  " + entries.size() + " 词"; }
    }
    private final AtomicFile file;
    WordStore(Context context) { file = new AtomicFile(new File(context.getFilesDir(), "decks.json")); }
    List<Deck> load() throws Exception {
        List<Deck> decks = new ArrayList<>();
        if (!file.getBaseFile().exists()) return decks;
        JSONArray array = new JSONArray(new String(file.readFully(), StandardCharsets.UTF_8));
        for (int i = 0; i < array.length(); i++) {
            JSONObject obj = array.getJSONObject(i);
            JSONArray items = obj.getJSONArray("entries");
            List<CsvParser.Entry> entries = new ArrayList<>();
            for (int j = 0; j < items.length(); j++) {
                JSONObject e = items.getJSONObject(j);
                entries.add(new CsvParser.Entry(e.getString("word"), e.getString("sentence")));
            }
            if (!entries.isEmpty()) decks.add(new Deck(obj.getString("name"), entries));
        }
        return decks;
    }
    void save(List<Deck> decks) throws Exception {
        JSONArray array = new JSONArray();
        for (Deck deck : decks) {
            JSONArray entries = new JSONArray();
            for (CsvParser.Entry e : deck.entries) entries.put(new JSONObject().put("word", e.word).put("sentence", e.sentence));
            array.put(new JSONObject().put("name", deck.name).put("entries", entries));
        }
        FileOutputStream stream = null;
        try {
            stream = file.startWrite();
            stream.write(array.toString().getBytes(StandardCharsets.UTF_8));
            file.finishWrite(stream);
        } catch (Exception e) { if (stream != null) file.failWrite(stream); throw e; }
    }
}
