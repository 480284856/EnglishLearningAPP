package cn.wordflow.app;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final int GREEN = 0xff267567, INK = 0xff203b34, MUTED = 0xff6c7c74, BG = 0xfff6f7f2;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private List<WordStore.Deck> decks = new ArrayList<>();
    private WordStore store;
    private boolean ready, playing, importing, destroyed;
    private int deckIndex, wordIndex, phase;
    private float rate = 0.85f;
    private Spinner deckPicker;
    private ArrayAdapter<WordStore.Deck> deckAdapter;
    private TextView status, word, sentence, progress, rateLabel, empty;
    private Button play, importButton, remove;
    private ListView list;
    private BaseAdapter entriesAdapter;
    private CheckBox loop;
    private PlaybackService playback;
    private boolean bound;
    private final PlaybackService.Listener playbackListener = state -> {
        ready = state.ready; playing = state.playing;
        if (state.hasDeck && state.deckIndex < decks.size()) {
            deckIndex = state.deckIndex; wordIndex = state.wordIndex; phase = state.phase;
            if (deckPicker.getSelectedItemPosition() != deckIndex) deckPicker.setSelection(deckIndex);
        }
        loop.setChecked(state.loop);
        status.setText(state.message); update();
    };
    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            playback = ((PlaybackService.LocalBinder)binder).service();
            playback.addListener(playbackListener);
            PlaybackService.State state = new PlaybackService.State(playback);
            rate = state.rate; rateLabel.setText(String.format(Locale.US, "语速 %.2f×", rate));
            speed.setProgress(Math.round((rate - 0.5f) * 100));
            if (!state.hasDeck && !decks.isEmpty()) syncDeck();
        }
        @Override public void onServiceDisconnected(ComponentName name) {
            playback = null; ready = false; playing = false;
            status.setText("播放服务已断开，请重新打开应用"); update();
        }
    };
    private SeekBar speed;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        store = new WordStore(this);
        try { decks = store.load(); } catch (Exception e) { message("词表读取失败", "保存的数据无法读取。请保留应用数据，重新打开应用后再试。"); }
        if (state != null) { deckIndex = state.getInt("deck"); wordIndex = state.getInt("word"); phase = state.getInt("phase"); }
        if (!getSharedPreferences("playback", MODE_PRIVATE).contains("rate"))
            getSharedPreferences("playback", MODE_PRIVATE).edit().putFloat("rate", getPreferences(0).getFloat("rate", 0.85f)).apply();
        rate = getSharedPreferences("playback", MODE_PRIVATE).getFloat("rate", 0.85f);
        if (deckIndex >= decks.size()) deckIndex = 0;
        if (!decks.isEmpty() && wordIndex >= current().entries.size()) wordIndex = 0;
        buildUi(); refreshDecks();
    }
    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20), dp(12), dp(20), dp(8)); root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((v, insets) -> { v.setPadding(dp(20), dp(12) + insets.getSystemWindowInsetTop(), dp(20), dp(8) + insets.getSystemWindowInsetBottom()); return insets; });
        setContentView(root);
        TextView brand = text("词间  /  WordFlow", 27, INK); brand.setTypeface(null, Typeface.BOLD); root.addView(brand);
        root.addView(text("Kokoro 离线听读 · 让单词留在句子里。", 14, MUTED));
        LinearLayout top = row(); root.addView(top);
        importButton = button("＋ 导入 CSV", v -> chooseCsv()); top.addView(importButton, weighted());
        Button help = button("格式说明", v -> message("CSV 导入格式", "请使用 UTF-8 编码的 CSV 文件。\n第一列：词汇\n第二列：英文例句\n\n支持无表头，或 word,sentence / 词汇,例句 表头。\n例句包含逗号或换行时，用双引号包围；内部双引号写成两个双引号。\n\n每次导入创建一个新词表。上限 5 MB、10,000 条，每个字段最多 3,500 字符。")); top.addView(help);
        deckPicker = new Spinner(this); deckAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, decks); deckPicker.setAdapter(deckAdapter); root.addView(deckPicker);
        deckPicker.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v, int position, long id) { if (deckIndex != position) { pause(); deckIndex = position; wordIndex = 0; phase = 0; syncDeck(); } update(); }
            public void onNothingSelected(AdapterView<?> p) { }
        });
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(18), dp(14), dp(18), dp(14)); card.setBackground(shape(Color.WHITE, 20)); root.addView(card);
        progress = text("开始你的第一张词表", 12, GREEN); card.addView(progress);
        word = text("Hello, learner.", 30, INK); word.setTypeface(null, Typeface.BOLD); word.setMaxLines(2); word.setEllipsize(android.text.TextUtils.TruncateAt.END); card.addView(word);
        sentence = text("导入词汇与例句，开始听读练习。", 17, MUTED); sentence.setMaxLines(4); sentence.setEllipsize(android.text.TextUtils.TruncateAt.END); sentence.setPadding(0, dp(6), 0, dp(10)); card.addView(sentence);
        LinearLayout controls = row(); card.addView(controls);
        controls.addView(button("上一词", v -> move(-1)), weighted());
        play = button("播放词表", v -> { if (playing) pause(); else start(); }); play.setTextColor(Color.WHITE); play.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GREEN)); controls.addView(play, weighted());
        controls.addView(button("下一词", v -> move(1)), weighted());
        status = text("正在准备 Kokoro 离线语音…", 12, MUTED); card.addView(status);
        LinearLayout options = row(); root.addView(options);
        rateLabel = text(String.format(Locale.US, "语速 %.2f×", rate), 13, MUTED); options.addView(rateLabel);
        speed = new SeekBar(this); speed.setMax(100); speed.setProgress(Math.round((rate - 0.5f) * 100)); options.addView(speed, weighted());
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int value, boolean user) { rate = 0.5f + value / 100f; rateLabel.setText(String.format(Locale.US, "语速 %.2f×", rate)); }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { getSharedPreferences("playback", MODE_PRIVATE).edit().putFloat("rate", rate).apply(); if (playback != null) playback.setRate(rate); }
        });
        loop = new CheckBox(this); loop.setText("循环"); loop.setTextSize(13); loop.setOnCheckedChangeListener((b, checked) -> { if (playback != null) playback.setLoop(checked); }); options.addView(loop);
        LinearLayout label = row(); root.addView(label); label.addView(text("词表  ·  点击任意一词开始听读", 13, MUTED), weighted());
        remove = button("删除", v -> deleteDeck()); label.addView(remove);
        empty = text("还没有词表\n点击「导入 CSV」添加你的学习内容", 16, MUTED); empty.setGravity(Gravity.CENTER); root.addView(empty, new LinearLayout.LayoutParams(-1, 0, 1));
        list = new ListView(this); list.setDividerHeight(dp(5)); list.setDivider(new android.graphics.drawable.ColorDrawable(BG)); root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        entriesAdapter = new BaseAdapter() {
            public int getCount() { return decks.isEmpty() ? 0 : current().entries.size(); }
            public Object getItem(int p) { return current().entries.get(p); }
            public long getItemId(int p) { return p; }
            public View getView(int p, View recycled, ViewGroup parent) {
                LinearLayout item;
                if (recycled == null) { item = new LinearLayout(MainActivity.this); item.setOrientation(LinearLayout.VERTICAL); item.setPadding(dp(14), dp(10), dp(14), dp(10)); TextView w = text("", 18, INK), s = text("", 14, MUTED); s.setMaxLines(3); s.setEllipsize(android.text.TextUtils.TruncateAt.END); item.addView(w); item.addView(s); } else item = (LinearLayout)recycled;
                CsvParser.Entry e = current().entries.get(p);
                ((TextView)item.getChildAt(0)).setText((p + 1) + "   " + e.word + (p == wordIndex ? "   •" : ""));
                ((TextView)item.getChildAt(1)).setText(e.sentence);
                item.setBackground(shape(p == wordIndex ? 0xffe1eee6 : Color.WHITE, 12));
                return item;
            }
        }; list.setAdapter(entriesAdapter);
        list.setOnItemClickListener((p, v, position, id) -> { pause(); wordIndex = position; phase = 0; syncDeck(); update(); start(); });
    }
    private WordStore.Deck current() { return decks.get(deckIndex); }
    private void refreshDecks() { deckAdapter.notifyDataSetChanged(); if (!decks.isEmpty()) deckPicker.setSelection(deckIndex); update(); }
    private void update() {
        boolean has = !decks.isEmpty();
        empty.setVisibility(has ? View.GONE : View.VISIBLE); list.setVisibility(has ? View.VISIBLE : View.GONE);
        deckPicker.setEnabled(has && !importing); remove.setEnabled(has && !importing); play.setEnabled(has && ready && !importing);
        play.setText(playing ? "暂停" : "播放词表");
        if (has) { CsvParser.Entry e = current().entries.get(wordIndex); word.setText(e.word); sentence.setText(e.sentence); progress.setText((wordIndex + 1) + " / " + current().entries.size() + "  ·  " + (playing ? (phase == 0 ? "正在读单词" : "正在读例句") : "单词 → 例句")); }
        else { word.setText("Hello, learner."); sentence.setText("导入词汇与例句，开始听读练习。"); progress.setText("开始你的第一张词表"); }
        entriesAdapter.notifyDataSetChanged();
    }
    private void syncDeck() {
        if (playback != null) playback.selectDeck(deckIndex, decks.isEmpty() ? null : current(), wordIndex, phase);
    }
    private void start() {
        if (!ready || decks.isEmpty() || importing || playback == null) return;
        try { startForegroundService(new Intent(this, PlaybackService.class).setAction(PlaybackService.PLAY)); }
        catch (IllegalStateException | SecurityException e) { status.setText("无法启动后台播放，请回到应用内重试"); }
    }
    private void pause() {
        if (playback != null) playback.pause("已暂停 · 继续时重读当前片段");
        else { playing = false; update(); }
    }
    private void move(int delta) { if (!decks.isEmpty() && !importing && playback != null) playback.move(delta); }
    private void chooseCsv() {
        if (importing) return;
        pause();
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);
        try { startActivityForResult(intent, 10); } catch (ActivityNotFoundException e) { message("无法选择文件", "请安装或启用系统文件管理器。"); }
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != 10 || result != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData(); importing = true; importButton.setEnabled(false); status.setText("正在导入…"); update();
        worker.execute(() -> {
            try {
                String name = "导入的词表";
                try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) { if (c != null && c.moveToFirst()) name = c.getString(0); }
                if (name == null || name.trim().isEmpty()) name = "导入的词表";
                name = name.replaceFirst("(?i)\\.csv$", "");
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new IOException("无法打开文件");
                    byte[] buffer = new byte[8192]; int n;
                    while ((n = in.read(buffer)) != -1) { if (bytes.size() + n > 5 * 1024 * 1024) throw new IOException("文件不能超过 5 MB"); bytes.write(buffer, 0, n); }
                }
                String csv = StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes.toByteArray())).toString();
                WordStore.Deck added = new WordStore.Deck(name, CsvParser.parse(csv));
                List<WordStore.Deck> next = new ArrayList<>(decks); next.add(added); store.save(next);
                runOnUiThread(() -> { if (destroyed) return; decks.clear(); decks.addAll(next); deckIndex = decks.size() - 1; wordIndex = 0; phase = 0; syncDeck(); finishImport(); refreshDecks(); status.setText("已导入 " + added.entries.size() + " 个词汇"); });
            } catch (Exception e) { runOnUiThread(() -> { if (destroyed) return; finishImport(); message("导入失败", e instanceof CharacterCodingException ? "文件不是有效的 UTF-8 编码。请另存为 CSV UTF-8 后重新导入。" : (e.getMessage() == null ? "无法读取该文件，请重试。" : e.getMessage())); status.setText("导入失败，现有词表已保留"); }); }
        });
    }
    private void finishImport() { importing = false; importButton.setEnabled(true); update(); }
    private void deleteDeck() {
        if (decks.isEmpty() || importing) return;
        pause();
        new AlertDialog.Builder(this).setTitle("删除「" + current().name + "」？").setMessage("删除后可通过原 CSV 重新导入。").setNegativeButton("取消", null).setPositiveButton("删除", (d, w) -> {
            List<WordStore.Deck> next = new ArrayList<>(decks); next.remove(deckIndex);
            try { store.save(next); decks.clear(); decks.addAll(next); deckIndex = 0; wordIndex = 0; phase = 0; syncDeck(); refreshDecks(); } catch (Exception e) { message("删除失败", "无法保存更改，请重试。"); }
        }).show();
    }
    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); out.putInt("deck", deckIndex); out.putInt("word", wordIndex); out.putInt("phase", phase); }
    @Override protected void onStart() {
        super.onStart();
        bound = bindService(new Intent(this, PlaybackService.class), connection, Context.BIND_AUTO_CREATE);
    }
    @Override protected void onStop() {
        if (playback != null) playback.removeListener(playbackListener);
        if (bound) { unbindService(connection); bound = false; }
        playback = null; ready = false;
        super.onStop();
    }
    @Override protected void onDestroy() { destroyed = true; worker.shutdown(); super.onDestroy(); }
    private void message(String title, String body) { new AlertDialog.Builder(this).setTitle(title).setMessage(body).setPositiveButton("知道了", null).show(); }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private TextView text(String value, int size, int color) { TextView v = new TextView(this); v.setText(value); v.setTextSize(size); v.setTextColor(color); v.setPadding(0, dp(3), 0, dp(3)); return v; }
    private Button button(String title, View.OnClickListener click) { Button b = new Button(this); b.setText(title); b.setAllCaps(false); b.setTextSize(13); b.setMinWidth(0); b.setMinimumWidth(0); b.setOnClickListener(click); return b; }
    private LinearLayout row() { LinearLayout v = new LinearLayout(this); v.setOrientation(LinearLayout.HORIZONTAL); v.setGravity(Gravity.CENTER_VERTICAL); return v; }
    private LinearLayout.LayoutParams weighted() { return new LinearLayout.LayoutParams(0, -2, 1); }
    private GradientDrawable shape(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
}
