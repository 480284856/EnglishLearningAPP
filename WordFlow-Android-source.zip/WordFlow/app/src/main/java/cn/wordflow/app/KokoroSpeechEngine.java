package cn.wordflow.app;

import android.content.Context;
import android.content.res.AssetManager;
import android.media.*;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import com.k2fsa.sherpa.onnx.*;
import java.io.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/** Offline Kokoro synthesis and PCM playback; the native model stays on one worker. */
final class KokoroSpeechEngine {
    interface Listener {
        void ready();
        void initializationFailed();
        void synthesizing(String token);
        void audioStarted(String token);
        void completed(String token);
        void failed(String token);
    }
    private static final Object INSTALL_LOCK = new Object();
    private static final Semaphore MODEL_SLOT = new Semaphore(1);
    private static final String MODEL_VERSION = "kokoro-int8-en-v0_19-c9f0dd39";
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final AtomicLong request = new AtomicLong();
    private final Object audioLock = new Object();
    private final Listener listener;
    private final Context context;
    private volatile boolean closed;
    private boolean ownsModelSlot;
    private OfflineTts model; // accessed exclusively on worker
    private AudioTrack track; // publish/release under audioLock; writes only on worker

    KokoroSpeechEngine(Context context, Listener listener) {
        this.context = context.getApplicationContext(); this.listener = listener;
        worker.execute(() -> {
            try {
                MODEL_SLOT.acquire(); ownsModelSlot = true;
                File files = prepareModel();
                if (closed) return;
                OfflineTtsConfig config = new OfflineTtsConfig();
                config.getModel().setNumThreads(2);
                config.getModel().setProvider("cpu");
                OfflineTtsKokoroModelConfig kokoro = config.getModel().getKokoro();
                kokoro.setModel(new File(files, "model.int8.onnx").getAbsolutePath());
                kokoro.setVoices(new File(files, "voices.bin").getAbsolutePath());
                kokoro.setTokens(new File(files, "tokens.txt").getAbsolutePath());
                kokoro.setDataDir(new File(files, "espeak-ng-data").getAbsolutePath());
                kokoro.setLang("en-us");
                model = new OfflineTts(null, config);
                if (model.sampleRate() <= 0 || model.numSpeakers() <= 0) throw new IOException("Invalid model");
                main.post(() -> { if (!closed) listener.ready(); });
            } catch (Exception | LinkageError | OutOfMemoryError e) {
                releaseModel();
                android.util.Log.e("WordFlowKokoro", "Kokoro initialization failed", e);
                main.post(() -> { if (!closed) listener.initializationFailed(); });
            }
        });
    }
    void speak(String text, float speed, String token) {
        stop();
        long id = request.get();
        worker.execute(() -> synthesize(text, speed, token, id));
    }
    private boolean current(long id) { return !closed && request.get() == id; }
    void stop() {
        request.incrementAndGet();
        synchronized (audioLock) {
            if (track != null) {
                try { track.pause(); track.flush(); track.stop(); } catch (IllegalStateException ignored) { }
            }
        }
    }
    private void synthesize(String text, float speed, String token, long id) {
        if (!current(id)) return;
        AudioTrack output = null;
        main.post(() -> { if (current(id)) listener.synthesizing(token); });
        try {
            if (model == null) throw new IllegalStateException("Kokoro not ready");
            int sampleRate = model.sampleRate();
            int minimum = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT);
            if (minimum <= 0) throw new IllegalStateException("Unsupported audio output");
            output = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(new AudioFormat.Builder().setSampleRate(sampleRate).setEncoding(AudioFormat.ENCODING_PCM_FLOAT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setTransferMode(AudioTrack.MODE_STREAM).setBufferSizeInBytes(Math.max(minimum, sampleRate)).build();
            synchronized (audioLock) {
                if (!current(id)) return;
                track = output; output.play();
            }
            final AudioTrack sink = output;
            final long[] written = {0};
            final boolean[] failed = {false}, started = {false};
            for (String chunk : SpeechChunks.split(text)) {
                if (!current(id)) return;
                model.generateWithCallback(chunk, 0, speed, new KokoroCallback() {
                    @Override protected int onSamples(float[] samples) {
                    // Never propagate Java exceptions across the native callback boundary.
                    try {
                        int offset = 0;
                        while (offset < samples.length && current(id)) {
                            int n = sink.write(samples, offset, Math.min(2048, samples.length - offset), AudioTrack.WRITE_BLOCKING);
                            if (n <= 0) { failed[0] = true; return 0; }
                            offset += n; written[0] += n;
                            if (!started[0]) {
                                started[0] = true;
                                main.post(() -> { if (current(id)) listener.audioStarted(token); });
                            }
                        }
                        return current(id) ? 1 : 0;
                    } catch (RuntimeException e) { failed[0] = true; return 0; }
                    }
                });
                if (failed[0] && current(id)) throw new IllegalStateException("Audio output failed");
            }
            if (written[0] == 0) throw new IllegalStateException("No speech generated");
            // Native generation completes before the audio device has drained its queue.
            long deadline = SystemClock.elapsedRealtime() + 20000;
            while (current(id) && (sink.getPlaybackHeadPosition() & 0xffffffffL) < written[0]) {
                if (SystemClock.elapsedRealtime() > deadline) throw new IllegalStateException("Audio output stalled");
                Thread.sleep(10);
            }
            main.post(() -> { if (current(id)) listener.completed(token); });
        } catch (Exception | LinkageError | OutOfMemoryError e) {
            android.util.Log.e("WordFlowKokoro", "Speech generation/playback failed", e);
            main.post(() -> { if (current(id)) listener.failed(token); });
        } finally {
            synchronized (audioLock) {
                if (track == output) track = null;
                if (output != null) output.release();
            }
        }
    }
    void close() {
        closed = true; stop();
        // Do not free the native model while an inference callback is still using it.
        worker.execute(this::releaseModel);
        worker.shutdown(); main.removeCallbacksAndMessages(null);
    }
    private void releaseModel() {
        try { if (model != null) { model.release(); model = null; } }
        finally { if (ownsModelSlot) { ownsModelSlot = false; MODEL_SLOT.release(); } }
    }
    private File prepareModel() throws IOException {
        synchronized (INSTALL_LOCK) {
            File target = new File(context.getNoBackupFilesDir(), MODEL_VERSION);
            File marker = new File(target, ".ready");
            if (marker.isFile() && new File(target, "model.int8.onnx").length() > 0) return target;
            copyAssets(context.getAssets(), "kokoro", target);
            try (FileOutputStream out = new FileOutputStream(marker)) { out.write(1); out.getFD().sync(); }
            return target;
        }
    }
    private void copyAssets(AssetManager assets, String path, File target) throws IOException {
        if (closed) throw new IOException("Cancelled");
        String[] children = assets.list(path);
        if (children != null && children.length > 0) {
            if (!target.isDirectory() && !target.mkdirs()) throw new IOException("Cannot create model directory");
            for (String child : children) copyAssets(assets, path + "/" + child, new File(target, child));
        } else {
            try (InputStream in = assets.open(path); FileOutputStream out = new FileOutputStream(target)) {
                byte[] buffer = new byte[65536]; int n;
                while ((n = in.read(buffer)) != -1) { if (closed) throw new IOException("Cancelled"); out.write(buffer, 0, n); }
            }
        }
    }
}
