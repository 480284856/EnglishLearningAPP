package cn.wordflow.app;

import android.app.*;
import android.content.*;
import android.media.*;
import android.media.session.*;
import android.os.*;
import java.util.*;

/** Owns TTS and audio resources independently of the visible activity. */
public final class PlaybackService extends Service {
    private static final String CHANNEL = "wordflow_playback";
    static final String PLAY = "cn.wordflow.app.PLAY", PAUSE = "cn.wordflow.app.PAUSE",
            PREVIOUS = "cn.wordflow.app.PREVIOUS", NEXT = "cn.wordflow.app.NEXT", STOP = "cn.wordflow.app.STOP";
    private static final int NOTICE = 41;
    final class LocalBinder extends Binder { PlaybackService service() { return PlaybackService.this; } }
    interface Listener { void changed(State state); }
    static final class State {
        final boolean ready, playing, loop, hasDeck;
        final int deckIndex, wordIndex, phase;
        final float rate;
        final String message;
        State(PlaybackService s) {
            ready = s.ready; playing = s.playing; loop = s.loop; hasDeck = s.deck != null;
            deckIndex = s.deckIndex; wordIndex = s.cursor.word; phase = s.cursor.phase;
            rate = s.rate; message = s.message;
        }
    }
    private final LocalBinder binder = new LocalBinder();
    private final List<Listener> listeners = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final PlaybackSequence cursor = new PlaybackSequence();
    private WordStore.Deck deck;
    private int deckIndex;
    private boolean ready, playing, foreground, destroyed, loop;
    private float rate;
    private String message = "正在准备 Kokoro 离线语音…";
    private KokoroSpeechEngine tts;
    private AudioManager audio;
    private AudioFocusRequest focus;
    private PowerManager.WakeLock wakeLock;
    private MediaSession session;
    private Runnable pending;
    private final BroadcastReceiver noisy = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { pause("耳机已断开 · 已暂停"); }
    };

    @Override public void onCreate() {
        super.onCreate();
        rate = getSharedPreferences("playback", MODE_PRIVATE).getFloat("rate", 0.85f);
        audio = (AudioManager)getSystemService(AUDIO_SERVICE);
        AudioAttributes attributes = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build();
        focus = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(attributes)
                .setOnAudioFocusChangeListener(change -> { if (change < 0) pause("音频被占用 · 已暂停"); }, handler).build();
        wakeLock = ((PowerManager)getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WordFlow:Playback");
        wakeLock.setReferenceCounted(false);
        registerReceiver(noisy, new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
        NotificationChannel channel = new NotificationChannel(CHANNEL, "词表播放", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("息屏听读及播放控制"); channel.setSound(null, null);
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
        session = new MediaSession(this, "WordFlow");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { startFromControl(); }
            @Override public void onPause() { pause("已暂停 · 继续时重读当前片段"); }
            @Override public void onSkipToNext() { move(1); }
            @Override public void onSkipToPrevious() { move(-1); }
            @Override public void onStop() { stopPlayback(); }
        }, handler);
        tts = new KokoroSpeechEngine(this, new KokoroSpeechEngine.Listener() {
            @Override public void ready() {
                if (destroyed) return;
                ready = true; message = "Kokoro 离线英语 · 支持息屏听读"; publish();
            }
            @Override public void initializationFailed() {
                if (destroyed) return;
                ready = false; message = "Kokoro 模型加载失败，请检查剩余空间并重新打开应用"; publish();
            }
            @Override public void synthesizing(String token) {
                if (playing && cursor.matches(token)) { message = "Kokoro 正在离线合成，请稍候…"; publish(); }
            }
            @Override public void audioStarted(String token) {
                if (playing && cursor.matches(token)) { message = "Kokoro 息屏听读中 · 单词 → 例句"; publish(); }
            }
            @Override public void completed(String token) { PlaybackService.this.completed(token); }
            @Override public void failed(String token) { speechError(token); }
        });
    }
    @Override public IBinder onBind(Intent intent) { return binder; }
    void addListener(Listener listener) { listeners.add(listener); listener.changed(new State(this)); }
    void removeListener(Listener listener) { listeners.remove(listener); }
    void selectDeck(int index, WordStore.Deck selected, int word, int phase) {
        playing = false; cancelSpeech(); releaseAudio();
        if (ready) message = "Kokoro 离线英语 · 支持息屏听读";
        deckIndex = index; deck = selected;
        cursor.reset(selected == null ? 0 : Math.max(0, Math.min(word, selected.entries.size() - 1)), phase == 1 ? 1 : 0);
        if (selected == null) finish("播放已停止"); else publish();
    }
    void setRate(float value) {
        rate = Math.max(0.5f, Math.min(1.5f, value));
        getSharedPreferences("playback", MODE_PRIVATE).edit().putFloat("rate", rate).apply();
        if (playing) { cancelSpeech(); speak(); } else publish();
    }
    void setLoop(boolean value) { if (loop != value) { loop = value; publish(); } }
    private void startFromControl() {
        // Foreground promotion precedes the Android 15 audio-focus request.
        if (!ready || deck == null) return;
        startForegroundService(new Intent(this, PlaybackService.class).setAction(PLAY));
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? STOP : intent.getAction();
        if (PLAY.equals(action)) {
            // Also satisfies the promotion deadline if a stale notification restarts us.
            startForeground(NOTICE, notification()); foreground = true;
            if (!ready || deck == null) { stopPlayback(); return START_NOT_STICKY; }
            if (!playing) {
                if (audio.requestAudioFocus(focus) != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                    finish("暂时无法获取音频焦点，请稍后重试");
                } else {
                    playing = true; session.setActive(true);
                    message = "息屏听读中 · 单词 → 例句"; speak();
                }
            }
        } else if (PAUSE.equals(action)) pause("已暂停 · 继续时重读当前片段");
        else if (NEXT.equals(action)) move(1);
        else if (PREVIOUS.equals(action)) move(-1);
        else stopPlayback();
        return START_NOT_STICKY;
    }
    void pause(String reason) {
        playing = false; cancelSpeech(); releaseAudio(); message = reason; publish();
    }
    private void cancelSpeech() {
        cursor.cancel();
        if (pending != null) { handler.removeCallbacks(pending); pending = null; }
        if (tts != null) tts.stop();
    }
    private void releaseAudio() {
        if (wakeLock.isHeld()) wakeLock.release();
        audio.abandonAudioFocusRequest(focus);
    }
    void move(int delta) {
        if (deck == null) return;
        boolean resume = playing;
        cancelSpeech(); cursor.reset(Math.max(0, Math.min(deck.entries.size() - 1, cursor.word + delta)), 0);
        if (resume) speak(); else publish();
    }
    private void speak() {
        if (!playing || deck == null || destroyed) return;
        // Renew for each fragment, including its following gap. The bound avoids a
        // permanent lock if an inference or audio-device callback stalls.
        wakeLock.acquire(30 * 60 * 1000L);
        String token = cursor.begin(); publish();
        CsvParser.Entry entry = deck.entries.get(cursor.word);
        tts.speak(cursor.phase == 0 ? entry.word : entry.sentence, rate, token);
    }
    private void completed(String token) {
        if (!playing || !cursor.matches(token)) return;
        if (!cursor.advance(token, deck.entries.size(), loop)) { finish("本轮词表已播放完成"); return; }
        publish();
        pending = () -> { pending = null; if (playing) speak(); };
        handler.postDelayed(pending, 450);
    }
    private void speechError(String token) {
        if (playing && cursor.matches(token)) pause("Kokoro 朗读失败，请重试或重新打开应用");
    }
    private void finish(String reason) {
        pause(reason); session.setActive(false);
        if (foreground) { stopForeground(STOP_FOREGROUND_REMOVE); foreground = false; }
        stopSelf();
    }
    private void stopPlayback() { finish("播放已停止"); }
    // Android 13 explicitly exempts MediaStyle notifications associated with a
    // MediaSession from POST_NOTIFICATIONS. This method posts only that category.
    @android.annotation.SuppressLint("NotificationPermission")
    private void publish() {
        if (destroyed) return;
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_SKIP_TO_NEXT
                | PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_STOP;
        session.setPlaybackState(new PlaybackState.Builder().setActions(actions)
                .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED, PlaybackState.PLAYBACK_POSITION_UNKNOWN, playing ? rate : 0).build());
        if (deck != null) {
            CsvParser.Entry entry = deck.entries.get(cursor.word);
            session.setMetadata(new MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE, entry.word)
                    .putString(MediaMetadata.METADATA_KEY_ARTIST, deck.name)
                    .putString(MediaMetadata.METADATA_KEY_DISPLAY_DESCRIPTION, entry.sentence).build());
        }
        if (foreground) getSystemService(NotificationManager.class).notify(NOTICE, notification());
        State state = new State(this);
        for (Listener listener : new ArrayList<>(listeners)) listener.changed(state);
    }
    private PendingIntent action(String name, int id) {
        Intent intent = new Intent(this, PlaybackService.class).setAction(name);
        return PLAY.equals(name) ? PendingIntent.getForegroundService(this, id, intent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT)
                : PendingIntent.getService(this, id, intent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }
    private Notification notification() {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String title = deck == null ? "词间 · WordFlow" : deck.entries.get(cursor.word).word;
        String detail = deck == null ? "准备播放词表" : deck.name + " · " + (cursor.word + 1) + "/" + deck.entries.size() + (playing ? " · 正在听读" : " · 已暂停");
        return new Notification.Builder(this, CHANNEL).setSmallIcon(R.drawable.ic_playback).setContentTitle(title)
                .setContentText(detail).setContentIntent(open).setOnlyAlertOnce(true).setOngoing(playing)
                .setVisibility(Notification.VISIBILITY_PUBLIC).setCategory(Notification.CATEGORY_TRANSPORT)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_previous, "上一词", action(PREVIOUS, 1)).build())
                .addAction(new Notification.Action.Builder(playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play,
                        playing ? "暂停" : "继续", action(playing ? PAUSE : PLAY, 2)).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_next, "下一词", action(NEXT, 3)).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "停止", action(STOP, 4)).build())
                .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0, 1, 2))
                .setDeleteIntent(action(STOP, 4)).build();
    }
    @Override public void onDestroy() {
        destroyed = true; playing = false; cancelSpeech(); releaseAudio();
        unregisterReceiver(noisy); session.release(); tts.close();
        handler.removeCallbacksAndMessages(null); listeners.clear();
        if (foreground) stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }
}
