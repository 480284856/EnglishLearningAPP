# 词间 · WordFlow 1.2 — Kokoro 离线听读

中文界面的原生 Android 英语学习应用。使用内置 **Kokoro-82M 英语 INT8 模型 + sherpa-onnx 1.12.15** 在手机本地合成语音；不需要 API Key、联网、Google 服务或系统 TTS 语音包。

## 安装与使用

本次交付的 `/workspace/WordFlow-1.2-Kokoro-debug.apk` 支持 Android 8.0 及以上的 ARM64 / ARM32 手机。与交付的 1.0 / 1.1 使用相同签名，直接覆盖安装，不要先卸载，以保留词表。

1. 首次打开等待模型准备完成，界面会显示「Kokoro 离线英语」。模型解包到应用私有目录，之后打开直接复用。请预留至少 500 MB 存储空间。
2. 点击「导入 CSV」，选择自己的单词与例句文件，或使用 `examples/daily-english.csv`。
3. 点击播放后按「单词 → 例句 → 下一单词」听读，支持暂停、继续、切词、循环及 0.5–1.5 倍语速。
4. 息屏或切到后台后继续播放；通知栏 / 锁屏提供暂停、继续、上一词、下一词等控制。

Kokoro 在手机 CPU 上进行推理。首次加载和每段语音的合成都需要时间，界面会显示合成状态；速度取决于设备。默认使用模型中的第 0 个英语声音（共 11 个声音，本版不提供声音切换）。本版内置英语模型，未打包多语言模型。

如果小米系统仍在锁屏后中断，可进入「应用信息 → 省电策略 / 电量与性能 → 无限制」。不同 MIUI / 澎湃 OS 的菜单名称略有不同。如需锁屏控制，请允许本应用显示通知和锁屏通知。

## 功能

- 每次导入创建独立词表，保存到应用私有目录；原 CSV 移动后仍可使用。支持切换和删除词表。
- CSV 支持 UTF-8 BOM、CRLF、可选表头、引号内的逗号 / 换行及双引号转义；整份文件验证并保存成功后才加入列表。
- 先读单词，再读对应例句，随后播放下一词；片段之间有 450ms 间隔，另有本地模型推理耗时。
- 暂停会立即停止当前音频，并取消旧合成结果；继续时重读当前片段。切词、切表和改语速后，过期回调不影响新播放。
- 长文本按句子及单词边界分成最多 240 个 UTF-16 单元的小段，限制单次合成和 PCM 内存占用。
- 前台媒体服务持有播放状态、Kokoro 模型及音频设备，与页面生命周期分离。播放期间按片段续期部分唤醒锁，暂停 / 结束 / 停止 / 服务销毁时释放。
- 耳机断开或失去音频焦点时暂停。通知中的停止操作会结束前台播放。
- 不申请网络、麦克风和共享存储权限。CSV 通过系统文件选择器导入，模型随安装包提供。新增的权限仅用于媒体前台服务和唤醒锁。

## CSV 格式

请使用 UTF-8（Excel 可选「CSV UTF-8」）保存。第一列词汇，第二列例句，两列都不能留空。可直接放数据，也支持 `word,sentence`、`word,example`、`词汇,例句` 表头。

```csv
word,sentence
curious,I am curious about the world.
practice,"With practice, you will become more confident."
remember,"She said, ""Remember to take a break."""
```

包含逗号或换行的字段用双引号包围，内部的双引号写成两个双引号。忽略空行。单个文件最多 5 MB、10,000 条，每个字段最多 3,500 个 UTF-16 单元。

## 构建

需要 JDK 17 或以上、Android SDK Platform 35 和 Build Tools 35.0.0。仓库提供 Gradle wrapper 8.9，AGP 8.7.3。运行时依赖为固定版本的 sherpa-onnx AAR 和 Kotlin 标准库 2.1.0；应用自身仍使用 Java 17。

源码 ZIP 不重复打包大模型及 AAR。先下载固定版本的资源；脚本验证官方发行文件 SHA-256，模型下载包约 98 MB，AAR 约 37 MB。预装 APK 已包含这些文件，手机不执行此下载步骤。

```sh
python3 scripts/prepare-kokoro.py
./gradlew testDebugUnitTest lintDebug assembleDebug
```

SDK 路径可通过 `local.properties` 中的 `sdk.dir` 或 `ANDROID_HOME` 指定。产物：`app/build/outputs/apk/debug/app-debug.apk`。这是调试签名版本；本次提供的 APK 已用与旧版一致的调试密钥签名。其他机器自动生成的调试密钥不同，不能直接覆盖安装本次 APK，需使用原有密钥。

Android Studio 中先执行资源准备脚本，再打开本目录，使用项目自带 wrapper 同步并运行 `app`。GitHub Actions 配置也包含资源下载及测试 / lint / APK 构建步骤。

独立 CSV 检查：`bash scripts/check-csv.sh`。播放游标、文本分段和 JNI 回调签名检查由 JUnit 运行。

## 依赖来源与许可

本应用源码按 GPL-3.0-or-later 提供，完整许可见 `LICENSE`。第三方模型及运行库分别遵循原始许可。

- 模型：官方 sherpa-onnx `tts-models` 发布的 `kokoro-int8-en-v0_19`，源模型 Kokoro-82M；Apache-2.0。
- sherpa-onnx 1.12.15：Apache-2.0；ONNX Runtime：MIT；Kotlin 标准库：Apache-2.0。
- 运行库内含 eSpeak NG 及其音素数据，授权为 GPL-3.0-or-later。
- 原始许可、版本及对应源码位置随 APK 打包在 `app/src/main/assets/licenses/`，详见 `THIRD-PARTY-NOTICES.txt`。第三方资源未作修改。

## 验证与设备验收

具体构建、校验及 Linux 推理测试记录见 `BUILD-VERIFICATION.md`。Linux 上成功合成音频，并使用实际 AAR 的 Java API 与应用同一 `KokoroCallback` 类测试 PCM 回调和取消生成。

尚未完成安卓模拟器、小米真机的音频及长期息屏验收。建议在设备上确认：

- 覆盖安装后保留词表，首次模型准备完成后，飞行模式下能播放单词和例句。
- 连续播放、暂停续播、切词、快速切表、调整语速和循环正常。
- 息屏及切后台后持续播放多个条目，返回页面后位置和状态同步。
- 通知 / 锁屏控制生效，停止后通知移除；耳机断开或其他应用抢占音频时暂停。
- 长例句能完整播完，反复暂停 / 继续不会混播旧音频。
- 无效 CSV 导入失败时原词表保留，确认删除只移除所选词表。
